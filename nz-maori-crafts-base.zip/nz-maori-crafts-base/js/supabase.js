/*********************************************************************
 *                          Maori Fine Crafts Site                   *
 * CIS 5620: Authoring Websites                                      *
 *********************************************************************/

(async (window) => {
    const supabaseURL = '[URL TO YOUR SUPABASE PROJECT]';
    const supabaseKey = '[SUPABASE KEY]';

    const supabaseDB = supabase.createClient(supabaseURL, supabaseKey);

    /* Id of guest customer to be used when storing cart items.
    In this version of the application, we will keep the same customer id. */
    const GUEST_ID = 1;

    /**
        Submit cart's content for storage in Supabase
    
        @returns  No value.
    */
    window.addCartItems = async function submitCart() {
        /* Map products to array of product id and customer id pairs, e.g.,
            [
                {product_id: 1, customer_id: 1},
                {product_id: 2, customer_id: 1},
                ...
            ]
        */
        const cartProducts = CART.map(productId => ( {product_id: productId, customer_id: GUEST_ID} ));

        /* Persist items in the shopping cart:
            This means to create to create a record on the Cart_Item table that
            represents each item in the shopping cart.
          */

        /* YOUR CODE HERE (REFER TO SUPABASE'S JAVASCRIPT DOCUMENTATION) */

        if(error) {
            console.log("*** ERROR:", error);
            return false;
        }

        return true;
    }

    /* 
    Destructuring variable assignment
        https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment
    */

    /* Get all products for display:
        This means to query all rows and all columns from the Product table
        */

    /* YOUR CODE HERE (REFER TO SUPABASE'S JAVASCRIPT DOCUMENTATION) */

    const products = null;

    /* 
    Make the products data globally available through the window object
        https://developer.mozilla.org/en-US/docs/Web/API/Window
    */
    window.PRODUCTS = products;

    $(document).ready(function () {
        showProducts(PRODUCTS);
    });    
})(window);
